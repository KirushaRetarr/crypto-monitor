const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const app = express();
const port = 3000;

// Middleware для парсинга JSON
app.use(express.json());
app.use(express.static('.'));

// Путь к файлу users.json
const usersFilePath = path.join(__dirname, 'data', 'users.json');

// Функция для чтения существующих пользователей
async function readUsers() {
    try {
        const data = await fs.readFile(usersFilePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

// Функция для сохранения пользователей
async function saveUsers(users) {
    await fs.writeFile(usersFilePath, JSON.stringify(users, null, 2));
}

// Обработка POST запроса для сохранения пользователя
app.post('/api/register', async (req, res) => {
    try {
        const { name, email } = req.body;
        
        // Валидация данных
        if (!name || !email) {
            return res.status(400).json({ error: 'Имя и email обязательны' });
        }

        // Чтение существующих пользователей
        const users = await readUsers();

        // Проверка на существующий email
        if (users.some(user => user.email === email)) {
            return res.status(400).json({ error: 'Этот email уже зарегистрирован' });
        }

        // Добавление нового пользователя
        const newUser = {
            id: Date.now(),
            name,
            email,
            registeredAt: new Date().toISOString()
        };

        users.push(newUser);
        await saveUsers(users);

        res.json({ success: true, message: 'Пользователь успешно зарегистрирован' });
    } catch (error) {
        console.error('Ошибка при регистрации:', error);
        res.status(500).json({ error: 'Внутренняя ошибка сервера' });
    }
});

app.listen(port, () => {
    console.log(`Сервер запущен на http://localhost:${port}`);
}); 